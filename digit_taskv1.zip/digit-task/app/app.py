from flask import Flask, request, abort, Response, g, jsonify
import mysql.connector
from mysql.connector import Error, pooling
from mysql.connector.connection import MySQLConnection

import json
import redis

app = Flask(__name__)


# @app.before_first_request
# def setup_mysql():
#     try:
#         g.cnx_pool = mysql.connector.pooling.MySQLConnectionPool(
#             pool_name="mysql_pool",
#             pool_size=10,
#             pool_reset_session=True,
#             host='db',
#             database='digit',
#             user='root',
#             password='root'
#         )
#     except Error as mysql_error:
#         print("Error while connecting to mysql using connection pool", mysql_error)


@app.route('/createPlayer', methods=['POST'])
def create_player():
    connection = None
    req_data = request.get_json()
    player_identifier = req_data['identifier']
    player_name = req_data['name']
    gold_amount = req_data['goldAmount']
    if player_identifier is None or player_name is None or gold_amount is None:
        error_message = dumps({'Message': 'Invalid Data'})
        abort(Response(error_message, 412))
    if len(player_name) > 20:
        error_message = dumps({'Message': 'Player Name should be less than 20 chars'})
        abort(Response(error_message, 412))
    if gold_amount < 0 or gold_amount > 1000000000 or isinstance(gold_amount, int) is not True:
        error_message = dumps(
            {'Message': 'Amount of Gold should be an integer and less than 1000000000 and greater than 0'})
        abort(Response(error_message, 412))
    create_player_query = """ INSERT INTO Player (Identifier, name, amountGold) VALUES (%s,%s,%s)"""
    player_values = (player_identifier, player_name, gold_amount)
    try:
        # connection = g.cnx_pool.get_connection()
        connection = mysql.connector.connect(
            host='db',
            database='digit',
            user='root',
            password='root'
        )
        cursor = connection.cursor()
        connection.autocommit = False
        cursor.execute(create_player_query, player_values)
        connection.commit()
        add_to_redis(gold_amount,player_identifier, player_name)
        connection.close()
        return Response(status=200)
    except Error as error:
        print("Failed to execute insert statement rolling back", error)
        connection.rollback()
        connection.close()
        return Response(status=422)


def add_to_redis(score, identifier, name):
    redis_conn = redis.Redis(host='cache', port='6379', db=0)
    player_details = json.dumps({"name": name, "identifier": identifier})
    redis_conn.lpush(score, player_details)

@app.route('/getleaderboard')
def get_leaderboard():
    leaderboard = {}
    redis_conn = redis.Redis(host='cache', port='6379', db=0)
    leaderboard_scores = redis_conn.keys()
    leaderboard_scores.sort(reverse=True)
    leaderboardPlayers = []
    rank = 1
    for key in leaderboard_scores:
        players = []
        while redis_conn.llen(key) != 0:
            player = redis_conn.lpop(key)
            players.append(player)
        for player in players:
            redis_conn.lpush(key, player)
            player = json.loads(player.decode('utf-8'))
            player['score'] = key.decode('utf-8')
            leaderboardPlayers.append(player)
        leaderboard[rank] = leaderboardPlayers
        rank = rank + 1
    return leaderboard


if __name__ == '__main__':
    app.run(host='0.0.0.0')
