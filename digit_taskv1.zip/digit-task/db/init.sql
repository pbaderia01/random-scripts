
CREATE DATABASE digit;
use digit;

CREATE TABLE Player (
  Identifier VARCHAR(20),
  name VARCHAR(20) NOT NULL UNIQUE,
  amountGold INT CHECK (amountGold BETWEEN 0 and 1000000000)
);

-- Alternatively


/*CREATE TABLE Player (
  Identifier VARCHAR(20),
  name VARCHAR(20) NOT NULL UNIQUE,
  amountGold INT
);

CREATE TRIGGER check amountGoldValue
  BEFORE INSERT
  ON Player
  FOR EACH ROW
BEGIN
  IF NEW.amountGold<0 OR NEW.amountGold>1000000000 THEN
    CALL `Error: Invalid Value For amountGold`;
  END IF;
END */
